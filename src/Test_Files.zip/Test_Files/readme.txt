Testfiles for the characteristic feature extraction pipeline.

preprocessed_data.csv: Main file addressed by the original_path

Genname.csv: Used to name the features

comparision_lables.csv: Used after the classification to check for purity of clusters with respect to certain phenotypic characteristics.